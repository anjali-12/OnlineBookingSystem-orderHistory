import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import { Order } from './order';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http:HttpClient) { 
   
  }
  viewOrder():Observable<any>{
    return this.http.get(`http://localhost:8088/`+'vieworder');
  }
}
