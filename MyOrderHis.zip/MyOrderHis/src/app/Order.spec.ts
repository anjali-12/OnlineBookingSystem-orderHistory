import { Order } from './Order';

describe('Order.Ts', () => {
  it('should create an instance', () => {
    expect(new Order()).toBeTruthy();
  });
});
