import { Component, OnInit } from '@angular/core';
import { Order } from '../order';
import {OrderService} from '../orders.service';

@Component({
  selector: 'app-vieworder',
  templateUrl: './vieworder.component.html',
  styleUrls: ['./vieworder.component.css']
})
export class ViewOrderComponent implements OnInit {
  orders:Order[]=[];

  constructor(private ordersService:OrderService ) { }

  ngOnInit() {
    console.log("Am inside view component");
    this.ordersService.viewOrder().subscribe(data=>this.orders=data);
    console.log(this.orders);
  }

}
