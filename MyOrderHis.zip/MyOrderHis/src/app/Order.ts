export class Order{
        orderId:number;
        qty:number;
        total:number;
        status:string;
        payment:string;
        date:Date;
}



